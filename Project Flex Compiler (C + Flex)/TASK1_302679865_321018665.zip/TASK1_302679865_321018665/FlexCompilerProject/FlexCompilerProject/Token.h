#ifndef TOKEN_H
#define TOKEN_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern FILE *yyin, *yyout;

typedef enum eTOKENS
{
	ID,
	DIGIT,
	LETTER,
	INT_NUMBER,
	REAL_NUMBER,
	SPACE,
	TAB,
	NEW_LINE,
	PROGRAM,
	END,
	REAL,
	INTEGER,
	VOID,
	RETURN,
	MULTIPLICATION,
	DIVISION,
	ASSIGNMENT,
	COMMA,
	SEMICOLON,
	BRACKETS_OPEN,
	BRACKETS_CLOSE,
	BRACES_OPEN,
	BRACES_CLOSE,
	PARENTHESES_OPEN,
	PARENTHESES_CLOSE,
	EOF_TOKEN,
	UNDEFINED
}eTOKENS;

typedef struct Token
{
	eTOKENS kind;
	char *lexeme;
	int lineNumber;
}Token;

typedef struct Node
{
	Token *tokensArray;
	struct Node *prev;
	struct Node *next;
} Node;

void create_and_store_token(eTOKENS kind, char* lexeme, int numOfLine);
Token *next_token();
Token *back_token();

#endif
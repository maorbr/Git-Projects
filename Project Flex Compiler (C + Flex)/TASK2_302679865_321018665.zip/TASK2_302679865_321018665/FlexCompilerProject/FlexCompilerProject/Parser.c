﻿#include"parser.h"
#include"token.h"
#include"recover.h"

Token *CurrentToken;
FILE * SynFile;

void InitializeFile(FILE* output)
{
	SynFile = output;
}

void printSyntacticError(Token *CurrentToken, int Kind)
{
	fprintf(SynFile, "Expected token of type '{%s}' at line: {%d},Actual token of type '{%s}', lexeme: '{%s}'.\n", kindToText(Kind), CurrentToken->lineNumber, kindToText(CurrentToken->kind), CurrentToken->lexeme);
}

//1.	PROGRAM -> program VAR_DEFINITIONS; STATEMENTS end FUNC_DEFINITIONS
void parse_PROGRAM()
{
	printf("Enter parse_PROGRAM\n");
	printRule(1);
	if (match(PROGRAM))
	{
		parse_VAR_DEFINITIONS();
		if (match(SEMICOLON))
		{
			parse_STATEMENTS();

			if (match(END))
			{
				parse_FUNC_DEFINITIONS();
			}
			else
			{
				CurrentToken = recover_PROGRAM(END, CurrentToken);
			}
		}
		else
		{
			CurrentToken = recover_PROGRAM(SEMICOLON, CurrentToken);
		}
	}
	else
	{
		CurrentToken = recover_PROGRAM(PROGRAM, CurrentToken);
	}
	printf("Exit parse_PROGRAM\n");
}

//2.	VAR_DEFINITIONS -> VAR_DEFINITION VAR_DEFINITIONS_1
void parse_VAR_DEFINITIONS()
{
	printRule(2);
	parse_VAR_DEFINITION();
	parse_VAR_DEFINITIONS_1();
}

//3.	VAR_DEFINITION -> TYPE VARIABLES_LIST
void parse_VAR_DEFINITION()
{
	printRule(3);
	parse_TYPE();
	parse_VARIABLES_LIST();
}

//4.	VAR_DEFINITIONS_1 -> ; VAR_DEFINITIONS
//5.	VAR_DEFINITIONS_1 -> ε
void parse_VAR_DEFINITIONS_1()
{
	CurrentToken = next_token();
	switch (CurrentToken->kind)
	{
		case SEMICOLON:
		{
			CurrentToken = next_token();
			switch (CurrentToken->kind)
			{
			case ID:
			{
				printRule(5);
				CurrentToken = back_token();
				CurrentToken = back_token();
				break;
			}
			case RETURN:
			{
				printRule(5);
				CurrentToken = back_token();
				CurrentToken = back_token();
				break;
			}
			case BRACES_OPEN:
			{
				printRule(5);
				CurrentToken = back_token();
				CurrentToken = back_token();
				break;
			}
			case REAL:
			{
				printRule(4);
				CurrentToken = back_token();
				parse_VAR_DEFINITIONS();
				break;
			}
			case INTEGER:
			{
				printRule(4);
				CurrentToken = back_token();
				parse_VAR_DEFINITIONS();
				break;
			}
			default:
			{
				fprintf(SynFile, "Syntax error in line %d: expected '%s'/'%s'/'%s'/'%s'/'%s', got '%s'\n",
					CurrentToken->lineNumber,
					kindToText(ID),
					kindToText(RETURN),
					kindToText(BRACES_OPEN),
					kindToText(REAL),
					kindToText(INTEGER),
					CurrentToken->lexeme);

				while (!follow_VAR_DEFINITIONS_1(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
					CurrentToken = next_token();
				if (CurrentToken->kind == EOF_TOKEN) {
					printf("Exit with Error 4,5");
					exit(1);
				}
				else
				{
					CurrentToken = back_token();
				}
				break;
			}
		}
		break;
		}
		case PARENTHESES_CLOSE:
		{
			printRule(5);
			CurrentToken = back_token();
			break;
		}
		default:
		{
			fprintf(SynFile, "Syntax error in line %d: expected '%s'/'%s', got '%s'\n",
				CurrentToken->lineNumber,
				kindToText(SEMICOLON),
				kindToText(PARENTHESES_CLOSE),
				CurrentToken->lexeme);
			while (!follow_VAR_DEFINITIONS_1(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
				CurrentToken = next_token();
			if (CurrentToken->kind == EOF_TOKEN) {
				printf("Exit with Error 4,5");
				exit(1);
			}
			else
			{
				CurrentToken = back_token();
				break;
			}
		}
	}
}

//6. FUNC_DEFINITION -> RETURNED_TYPE id (PARAM_DEFINITIONS) BLOCK 
void parse_FUNC_DEFINITION()
{
	printRule(6);
	parse_RETURNED_TYPE();
	if (match(ID))
	{
		if (match(PARENTHESES_OPEN))
		{
			parse_PARAM_DEFINITIONS();
			if (match(PARENTHESES_CLOSE))
			{
				parse_BLOCK();
			}
			else
			{
				CurrentToken = recover_FUNC_DEFINITION(PARENTHESES_CLOSE, CurrentToken);
			}
		}
		else
		{
			CurrentToken = recover_FUNC_DEFINITION(PARENTHESES_OPEN, CurrentToken);
		}
	}
	else
	{
		CurrentToken = recover_FUNC_DEFINITION(ID, CurrentToken);
	}
}

//7.	FUNC_DEFINITIONS -> FUNC_DEFINITION FUNC_DEFINITIONS_1
void parse_FUNC_DEFINITIONS()
{
	printRule(7);
	parse_FUNC_DEFINITION();
	parse_FUNC_DEFINITIONS_1();
}

//8.	FUNC_DEFINITIONS_1 -> FUNC_DEFINITION FUNC_DEFINITIONS_1
//9.	FUNC_DEFINITIONS_1 -> ε
void parse_FUNC_DEFINITIONS_1()
{
	CurrentToken = next_token();
	switch (CurrentToken->kind)
	{
		case VOID:
		{
			printRule(8);
			CurrentToken = back_token();
			parse_FUNC_DEFINITION();
			parse_FUNC_DEFINITIONS_1();
			break;
		}
		case REAL:
		{
			printRule(8);
			CurrentToken = back_token();
			parse_FUNC_DEFINITION();
			parse_FUNC_DEFINITIONS_1();
			break;
		}
		case INTEGER:
		{
			printRule(8);
			CurrentToken = back_token();
			parse_FUNC_DEFINITION();
			parse_FUNC_DEFINITIONS_1();
			break;
		}
		case EOF_TOKEN:
		{
			printRule(9);
			CurrentToken = back_token();
			break;
		}
		default:
		{
			fprintf(SynFile, "Syntax error in line %d: expected '%s'/'%s'/'%s'/'%s', got '%s'\n",
				CurrentToken->lineNumber,
				kindToText(VOID),
				kindToText(REAL),
				kindToText(INTEGER),
				kindToText(EOF_TOKEN),
				CurrentToken->lexeme);
			while (!follow_FUNC_DEFINITION(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
				CurrentToken = next_token();
			if (CurrentToken->kind == EOF_TOKEN) {
				printf("Exit with Error 8,9");
				exit(1);
			}
			else {
				CurrentToken = back_token();
				parse_FUNC_DEFINITIONS_1();
				break;
			}
		}
	}
}

//10.	RETURNED_TYPE -> void
//11.	RETURNED_TYPE -> TYPE
void parse_RETURNED_TYPE()
{
	CurrentToken = next_token();
	switch (CurrentToken->kind)
	{
		case VOID:
		{
			printRule(10);
			break;
		}
		case REAL:
		{
			printRule(11);
			CurrentToken = back_token();
			parse_TYPE();
			break;
		}
		case INTEGER:
		{
			printRule(11);
			CurrentToken = back_token();
			parse_TYPE();
			break;
		}
		default:
		{
			fprintf(SynFile, "Syntax error in line %d: expected '%s'/'%s'/'%s', got '%s'\n",
				CurrentToken->lineNumber,
				kindToText(VOID),
				kindToText(REAL),
				kindToText(INTEGER),
				CurrentToken->lexeme);
			while (!follow_RETURNED_TYPE(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
				CurrentToken = next_token();
			if (CurrentToken->kind == EOF_TOKEN) {
				printf("Exit with Error 10,11");
				exit(1);
			}
			else {
				CurrentToken = back_token();
				break;
			}
		}
	}
}

//12. PARAM_DEFINITIONS -> VAR_DEFINITIONS
//13. PARAM_DEFINITIONS -> ε
void parse_PARAM_DEFINITIONS()
{
	CurrentToken = next_token();
	switch (CurrentToken->kind)
	{
		case REAL:
		{
			printRule(12);
			CurrentToken = back_token();
			parse_VAR_DEFINITIONS();
			break;
		}
		case INTEGER:
		{
			printRule(12);
			CurrentToken = back_token();
			parse_VAR_DEFINITIONS();
			break;
		}
		case PARENTHESES_CLOSE:
		{
			printRule(13);
			CurrentToken = back_token();
			break;
		}
		default:
		{
			fprintf(SynFile, "Syntax error in line %d: expected '%s'/'%s'/'%s', got '%s'\n",
				CurrentToken->lineNumber,
				kindToText(REAL),
				kindToText(INTEGER),
				kindToText(PARENTHESES_CLOSE),
				CurrentToken->lexeme);
			while (!follow_PARAM_DEFINITIONS(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
				CurrentToken = next_token();
			if (CurrentToken->kind == EOF_TOKEN) {
				printf("Exit with Error 12,13");
				exit(1);
			}
			else {
				CurrentToken = back_token();
				break;
			}
		}
	}
}

//14.	BLOCK -> { VAR_DEFINITIONS; STATEMENTS }
void parse_BLOCK()
{
	printRule(14);
	if (match(BRACES_OPEN))
	{
		parse_VAR_DEFINITIONS();
		if (match(SEMICOLON))
		{
			parse_STATEMENTS();

			if (!match(BRACES_CLOSE))
			{
				CurrentToken = recover_BLOCK(BRACES_CLOSE, CurrentToken);
			}
		}
		else
		{
			CurrentToken = recover_BLOCK(SEMICOLON, CurrentToken);
		}
	}
	else
	{
		CurrentToken = recover_BLOCK(BRACES_OPEN, CurrentToken);
	}
}

//15.	STATEMENTS -> STATEMENT; STATEMENTS_1
void parse_STATEMENTS()
{
	printRule(15);
	parse_STATEMENT();
	if (match(SEMICOLON))
	{
		parse_STATEMENTS_1();
	}
	else
	{
		CurrentToken = recover_STATEMENTS(SEMICOLON, CurrentToken);
	}
}
//16.	STATEMENTS_1 -> STATEMENTS
//17.	STATEMENTS_1 -> ε
void parse_STATEMENTS_1()
{
	CurrentToken = next_token();
	switch (CurrentToken->kind)
	{
		case RETURN:
		{
			printRule(16);
			CurrentToken = back_token();
			parse_STATEMENTS();
			break;
		}
		case ID:
		{
			printRule(16);
			CurrentToken = back_token();
			parse_STATEMENTS();
			break;
		}
		case BRACES_OPEN:
		{
			printRule(16);
			CurrentToken = back_token();
			parse_STATEMENTS();
			break;
		}
		case END:
		{
			printRule(17);
			CurrentToken = back_token();
			break;
		}
		case BRACES_CLOSE:
		{
			printRule(17);
			CurrentToken = back_token();
			break;
		}
		default:
		{
			fprintf(SynFile, "Syntax error in line %d: expected '%s'/'%s'/'%s'/'%s'/'%s', got '%s'\n",
				CurrentToken->lineNumber,
				kindToText(RETURN),
				kindToText(ID),
				kindToText(BRACES_OPEN),
				kindToText(END),
				kindToText(BRACES_CLOSE),
				CurrentToken->lexeme);
			while (!follow_STATEMENTS_1(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
				CurrentToken = next_token();
			if (CurrentToken->kind == EOF_TOKEN) {
				printf("Exit with Error 16,17");
				exit(1);
			}
			else {
				CurrentToken = back_token();
				break;
			}
		}
	}
}

//18.	STATEMENT -> BLOCK
//19.	STATEMENT -> return STATEMENT_1
//20.	STATEMENT -> id STATEMENT_2
void parse_STATEMENT()
{
	CurrentToken = next_token();
	switch (CurrentToken->kind)
	{
		case BRACES_OPEN:
		{
			printRule(18);
			CurrentToken = back_token();
			parse_BLOCK();
			break;
		}
		case RETURN:
		{
			printRule(19);
			parse_STATEMENT_1();
			break;
		}
		case ID:
		{
			printRule(20);
			parse_STATEMENT_2();
			break;
		}
		default:
		{
			fprintf(SynFile, "Syntax error in line %d: expected '%s'/'%s'/'%s', got '%s'\n",
				CurrentToken->lineNumber,
				kindToText(BRACES_OPEN),
				kindToText(RETURN),
				kindToText(ID),
				CurrentToken->lexeme);
			while (!follow_STATEMENT(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
				CurrentToken = next_token();
			if (CurrentToken->kind == EOF_TOKEN) {
				printf("Exit with Error 18,19,20");
				exit(1);
			}
			else {
				CurrentToken = back_token();
				break;
			}
		}
	}
}

//21.	STATEMENT_1 -> EXPRESSION
//22.	STATEMENT_1 -> ε
void parse_STATEMENT_1()
{
	CurrentToken = next_token();
	switch (CurrentToken->kind)
	{
		case INT_NUMBER:
		{
			printRule(21);
			CurrentToken = back_token();
			parse_EXPRESSION();
			break;
		}
		case REAL_NUMBER:
		{
			printRule(21);
			CurrentToken = back_token();
			parse_EXPRESSION();
			break;
		}
		case ID:
		{
			printRule(21);
			CurrentToken = back_token();
			parse_EXPRESSION();
			break;
		}
		case SEMICOLON:
		{
			printRule(22);
			CurrentToken = back_token();
			break;
		}
		default:
		{
			fprintf(SynFile, "Syntax error in line %d: expected '%s'/'%s'/'%s'/'%s', got '%s'\n",
				CurrentToken->lineNumber,
				kindToText(INT_NUMBER),
				kindToText(REAL_NUMBER),
				kindToText(ID),
				kindToText(SEMICOLON),
				CurrentToken->lexeme);
			while (!follow_STATEMENT_1(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
				CurrentToken = next_token();
			if (CurrentToken->kind == EOF_TOKEN) {
				printf("Exit with Error 16,17");
				exit(1);
			}
			else {
				CurrentToken = back_token();
				break;
			}
		}
	}
}

//23.	STATEMENT_2 -> VARIABLE_1 = EXPRESSION
//24.	STATEMENT_2 -> (PARAMETERS_LIST)
void parse_STATEMENT_2()
{
	CurrentToken = next_token();
	switch (CurrentToken->kind)
	{
		case BRACKETS_OPEN:
		{
			printRule(23);
			CurrentToken = back_token();
			parse_VARIABLE_1();
			if (match(ASSIGNMENT))
			{
				parse_EXPRESSION();
			}
			else
			{
				CurrentToken = recover_STATEMENT_2(ASSIGNMENT, CurrentToken);
			}
			break;
		}
		case PARENTHESES_OPEN:
		{
			printRule(24);
			parse_PARAMETERS_LIST();
			if (!match(PARENTHESES_CLOSE))
			{
				CurrentToken = recover_STATEMENT_2(PARENTHESES_CLOSE, CurrentToken);
			}
			break;
		}
		case ASSIGNMENT:
		{
			printRule(23);
			CurrentToken = back_token();
			if (match(ASSIGNMENT))
			{
				parse_EXPRESSION();
			}
			else
			{
				CurrentToken = recover_STATEMENT_2(ASSIGNMENT, CurrentToken);
			}
			break;
		}
		default:
		{
			fprintf(SynFile, "Syntax error in line %d: expected '%s'/'%s'/'%s', got '%s'\n",
				CurrentToken->lineNumber,
				kindToText(BRACKETS_OPEN),
				kindToText(PARENTHESES_OPEN),
				kindToText(ASSIGNMENT),
				CurrentToken->lexeme);
			while (!follow_STATEMENT_2(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
				CurrentToken = next_token();
			if (CurrentToken->kind == EOF_TOKEN) {
				printf("Exit with Error 23,24");
				exit(1);
			}
			else {
				CurrentToken = back_token();
				break;
			}
		}
	}
}

//25.	EXPRESSION-> int_number
//26.	EXPRESSION-> real_number
//27.	EXPRESSION-> id EXPRESSION_1
void parse_EXPRESSION()
{
	CurrentToken = next_token();
	switch (CurrentToken->kind)
	{
		case INT_NUMBER:
		{
			printRule(25);
			break;
		}
		case REAL_NUMBER:
		{
			printRule(26);
			break;
		}
		case ID:
		{
			printRule(27);
			parse_EXPRESSION_1();
			break;
		}
		default:
		{
			fprintf(SynFile, "Syntax error in line %d: expected '%s'/'%s'/'%s', got '%s'\n",
				CurrentToken->lineNumber,
				kindToText(INT_NUMBER),
				kindToText(REAL_NUMBER),
				kindToText(ID),
				CurrentToken->lexeme);
			while (!follow_EXPRESSION(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
				CurrentToken = next_token();
			if (CurrentToken->kind == EOF_TOKEN) {
				printf("Exit with Error 25,26,27");
				exit(1);
			}
			else {
				CurrentToken = back_token();
				break;
			}
		}
	}
}

//28.	EXPRESSION_1 -> VARIABLE_1
//29.	EXPRESSION_1 -> <ar_op> * EXPRESSION
//40.	EXPRESSION_1 -> <ar_op> / EXPRESSION
//41.	EXPRESSION_1 -> <ar_op> = EXPRESSION
void parse_EXPRESSION_1()
{
	CurrentToken = next_token();
	switch (CurrentToken->kind)
	{
		case BRACKETS_OPEN:
		{
			printRule(28);
			CurrentToken = back_token();
			parse_VARIABLE_1();
			break;
		}
		case MULTIPLICATION:
		{
			printRule(29);
			parse_EXPRESSION();
			break;
		}
		case DIVISION:
		{
			printRule(40);
			parse_EXPRESSION();
			break;
		}
		case ASSIGNMENT:
		{
			printRule(41);
			CurrentToken = back_token();
			parse_EXPRESSION();
			break;
		}
		case SEMICOLON: //check
		{
			printRule(28);
			CurrentToken = back_token();
			break;
		}
		default:
		{
			fprintf(SynFile, "Syntax error in line %d: expected '%s'/'%s'/'%s'/'%s', got '%s'\n",
				CurrentToken->lineNumber,
				kindToText(BRACKETS_OPEN),
				kindToText(MULTIPLICATION),
				kindToText(DIVISION),
				kindToText(ASSIGNMENT),
				CurrentToken->lexeme);
			while (!follow_EXPRESSION_1(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
				CurrentToken = next_token();
			if (CurrentToken->kind == EOF_TOKEN) {
				printf("Exit with Error 28,29,40,41");
				exit(1);
			}
			else {
				CurrentToken = back_token();
				break;
			}
		}
	}
}

//30. PARAMETERS_LIST -> VARIABLES_LIST
//31. PARAMETERS_LIST -> ε
void parse_PARAMETERS_LIST()
{
	CurrentToken = next_token();
	switch (CurrentToken->kind)
	{
		case ID:
		{
			printRule(30);
			CurrentToken = back_token();
			parse_VARIABLES_LIST();
			break;
		}
		case PARENTHESES_CLOSE:
		{
			printRule(31);
			CurrentToken = back_token();
			break;
		}
		default:
		{
			fprintf(SynFile, "Syntax error in line %d: expected '%s'/'%s', got '%s'\n",
				CurrentToken->lineNumber,
				kindToText(ID),
				kindToText(PARENTHESES_CLOSE),
				CurrentToken->lexeme);
			while (!follow_PARAMETERS_LIST(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
				CurrentToken = next_token();
			if (CurrentToken->kind == EOF_TOKEN) {
				printf("Exit with Error 30,31");
				exit(1);
			}
			else {
				CurrentToken = back_token();
				break;
			}
		}
	}
}

//32.	TYPE-> real
//33.	TYPE-> integer
void parse_TYPE()
{
	CurrentToken = next_token();
	switch (CurrentToken->kind)
	{
		case REAL:
		{
			printRule(32);
			break;
		}
		case INTEGER:
		{
			printRule(33);
			break;
		}
		default:
		{
			fprintf(SynFile, "Syntax error in line %d: expected '%s'/'%s', got '%s'\n", CurrentToken->lineNumber, kindToText(INTEGER), kindToText(REAL), CurrentToken->lexeme);
			while (!follow_TYPE(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
				CurrentToken = next_token();
			if (CurrentToken->kind == EOF_TOKEN) {
				printf("Exit with Error 32,33");
			}
			else {
				CurrentToken = back_token();
			}
			break;
		}
	}
}

//34.	VARIABLE -> id VARIABLE_1
void parse_VARIABLE()
{
	printRule(34);
	if (match(ID))
	{
		parse_VARIABLE_1();
	}
	else
	{
		CurrentToken = recover_VARIABLE(ID, CurrentToken);
	}
}

//35.	VARIABLE_1 -> [int_number]
//36.	VARIABLE_1 -> ε 
void parse_VARIABLE_1()
{
	CurrentToken = next_token();
	switch (CurrentToken->kind)
	{
		case BRACKETS_OPEN:
		{
			if (match(INT_NUMBER))
			{
				if (match(BRACKETS_CLOSE))
				{
					printRule(35);
				}
				else
				{
					CurrentToken = recover_VARIABLE_1(BRACKETS_CLOSE, CurrentToken);
				}
			}
			else
			{
				CurrentToken = recover_VARIABLE_1(INT_NUMBER, CurrentToken);
			}
			break;
		}
		case COMMA:
		{
			printRule(36);
			CurrentToken = back_token();
			break;
		}
		case SEMICOLON:
		{
			printRule(36);
			CurrentToken = back_token();
			break;
		}
		case ASSIGNMENT:
		{
			printRule(36);
			CurrentToken = back_token();
			break;
		}
		case PARENTHESES_CLOSE:
		{
			printRule(36);
			CurrentToken = back_token();
			break;
		}
		default:
		{
			fprintf(SynFile, "Syntax error in line %d: expected '%s'/'%s'/'%s'/'%s'/'%s', got '%s'\n",
				CurrentToken->lineNumber,
				kindToText(BRACKETS_OPEN),
				kindToText(COMMA),
				kindToText(SEMICOLON),
				kindToText(ASSIGNMENT),
				kindToText(PARENTHESES_CLOSE),
				CurrentToken->lexeme);
			while (!follow_VARIABLE_1(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
				CurrentToken = next_token();
			if (CurrentToken->kind == EOF_TOKEN) {
				printf("Exit with Error 35,36");
				exit(1);
			}
			else {
				CurrentToken = back_token();
				break;
			}
		}
	}
}

//37.	VARIABLES_LIST -> VARIABLE VARIABLES_LIST_1
void parse_VARIABLES_LIST()
{
	printRule(37);
	parse_VARIABLE();
	parse_VARIABLES_LIST_1();
}

//38.	VARIABLES_LIST_1 -> , VARIABLE VARIABLES_LIST_1
//39.	VARIABLES_LIST_1 -> ε 
void parse_VARIABLES_LIST_1()
{
	CurrentToken = next_token();
	switch (CurrentToken->kind)
	{
		case COMMA:
		{
			printRule(38);
			parse_VARIABLE();
			parse_VARIABLES_LIST_1();
			break;
		}
		case SEMICOLON:
		{
			printRule(39);
			CurrentToken = back_token();
			break;
		}
		case PARENTHESES_CLOSE:
		{
			printRule(39);
			CurrentToken = back_token();
			break;
		}
		default:
		{
			fprintf(SynFile, "Syntax error in line %d: expected '%s'/'%s'/'%s', got '%s'\n",
				CurrentToken->lineNumber,
				kindToText(COMMA),
				kindToText(SEMICOLON),
				kindToText(PARENTHESES_CLOSE),
				CurrentToken->lexeme);
			while (!follow_VARIABLES_LIST_1(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
				CurrentToken = next_token();
			if (CurrentToken->kind == EOF_TOKEN) {
				printf("Exit with Error 38,39");
				exit(1);
			}
			else
			{
				CurrentToken = back_token();
				break;
			}
		}
	}
}

int match(int Token) {
	CurrentToken = next_token();
	if (Token == CurrentToken->kind)
	{
		return 1;
	}
	return 0;
}

void printRule(int rule)
{
	switch (rule)
	{
	case 1: {	fprintf(SynFile, "Rule (PROGRAM -> program VAR_DEFINITIONS; STATEMENTS end FUNC_DEFINITIONS) \n");
		break; }
	case 2: {	fprintf(SynFile, "Rule (VAR_DEFINITIONS -> VAR_DEFINITION VAR_DEFINITIONS_1) \n");
		break; }
	case 3: {	fprintf(SynFile, "Rule (VAR_DEFINITION -> TYPE VARIABLES_LIST) \n");
		break; }
	case 4: {	fprintf(SynFile, "Rule (VAR_DEFINITIONS_1 -> ; VAR_DEFINITIONS) \n");
		break; }
	case 5: {	fprintf(SynFile, "Rule (VAR_DEFINITIONS_1 -> epsilon) \n");
		break; }
	case 6: {	fprintf(SynFile, "Rule (FUNC_DEFINITION -> RETURNED_TYPE id (PARAM_DEFINITIONS) BLOCK) \n");
		break; }
	case 7: {	fprintf(SynFile, "Rule (FUNC_DEFINITIONS -> FUNC_DEFINITION FUNC_DEFINITIONS_1) \n");
		break; }
	case 8: {	fprintf(SynFile, "Rule (FUNC_DEFINITIONS_1 -> FUNC_DEFINITION FUNC_DEFINITIONS_1) \n");
		break; }
	case 9: {	fprintf(SynFile, "Rule (FUNC_DEFINITIONS_1 -> epsilon) \n");
		break; }
	case 10: { fprintf(SynFile, "Rule (RETURNED_TYPE -> void) \n");
		break; }
	case 11: { fprintf(SynFile, "Rule (RETURNED_TYPE -> TYPE) \n");
		break; }
	case 12: { fprintf(SynFile, "Rule (PARAM_DEFINITIONS -> VAR_DEFINITIONS) \n");
		break; }
	case 13: { fprintf(SynFile, "Rule (PARAM_DEFINITIONS -> epsilon) \n");
		break; }
	case 14: { fprintf(SynFile, "Rule (BLOCK -> { VAR_DEFINITIONS; STATEMENTS }) \n");
		break; }
	case 15: { fprintf(SynFile, "Rule (STATEMENTS -> STATEMENT; STATEMENTS_1) \n");
		break; }
	case 16: { fprintf(SynFile, "Rule (STATEMENTS_1 -> STATEMENTS) \n");
		break; }
	case 17: { fprintf(SynFile, "Rule (STATEMENTS_1 -> epsilon) \n");
		break; }
	case 18: { fprintf(SynFile, "Rule (STATEMENT -> BLOCK) \n");
		break; }
	case 19: { fprintf(SynFile, "Rule (STATEMENT -> return STATEMENT_1) \n");
		break; }
	case 20: { fprintf(SynFile, "Rule (STATEMENT -> id STATEMENT_2) \n");
		break; }
	case 21: { fprintf(SynFile, "Rule (STATEMENT_1 -> EXPRESSION) \n");
		break; }
	case 22: { fprintf(SynFile, "Rule (STATEMENT_1 -> epsilon) \n");
		break; }
	case 23: { fprintf(SynFile, "Rule (STATEMENT_2 -> VARIABLE_1 = EXPRESSION) \n");
		break; }
	case 24: { fprintf(SynFile, "Rule (STATEMENT_2 -> (PARAMETERS_LIST)) \n");
		break; }
	case 25: { fprintf(SynFile, "Rule (EXPRESSION-> int_number) \n");
		break; }
	case 26: { fprintf(SynFile, "Rule (EXPRESSION-> real_number) \n");
		break; }
	case 27: { fprintf(SynFile, "Rule (EXPRESSION-> id EXPRESSION_1) \n");
		break; }
	case 28: { fprintf(SynFile, "Rule (EXPRESSION_1 -> VARIABLE_1) \n");
		break; }
	case 29: { fprintf(SynFile, "Rule (EXPRESSION_1 -> * EXPRESSION) \n");
		break; }
	case 30: { fprintf(SynFile, "Rule (PARAMETERS_LIST -> VARIABLES_LIST) \n");
		break; }
	case 31: { fprintf(SynFile, "Rule (PARAMETERS_LIST -> epsilon) \n");
		break; }
	case 32: { fprintf(SynFile, "Rule (TYPE-> real) \n");
		break; }
	case 33: { fprintf(SynFile, "Rule (TYPE-> integer) \n");
		break; }
	case 34: { fprintf(SynFile, "Rule (VARIABLE -> id VARIABLE_1) \n");
		break; }
	case 35: { fprintf(SynFile, "Rule (VARIABLE_1 -> [int_number]) \n");
		break; }
	case 36: { fprintf(SynFile, "Rule (VARIABLE_1 -> epsilon) \n");
		break; }
	case 37: { fprintf(SynFile, "Rule (VARIABLES_LIST -> VARIABLE VARIABLES_LIST_1) \n");
		break; }
	case 38: { fprintf(SynFile, "Rule (VARIABLES_LIST_1 -> , VARIABLE VARIABLES_LIST_1) \n");
		break; }
	case 39: { fprintf(SynFile, "Rule (VARIABLES_LIST_1 -> epsilon) \n");
		break; }
	case 40: { fprintf(SynFile, "Rule (EXPRESSION_1 -> / EXPRESSION) \n");
		break; }
	case 41: { fprintf(SynFile, "Rule (EXPRESSION_1 -> = EXPRESSION) \n");
		break; }
	}
}

char* kindToText(int kind)
{
	switch (kind)
	{
	case EOF_TOKEN:			return "EOF_TOKEN";
	case PROGRAM:			return "PROGRAM";
	case END:				return "END";
	case REAL:				return "REAL";
	case INTEGER:			return "INTEGER";
	case VOID:				return "VOID";
	case RETURN:			return "RETURN";
	case SEMICOLON:			return "SEMICOLON";
	case COMMA:				return "COMMA";
	case PARENTHESES_OPEN:	return "PARENTHESES_OPEN";
	case PARENTHESES_CLOSE:	return "PARENTHESES_CLOSE";
	case BRACKETS_OPEN:		return "BRACKETS_OPEN";
	case BRACKETS_CLOSE:	return "BRACKETS_CLOSE";
	case BRACES_OPEN:	    return "BRACES_OPEN";
	case BRACES_CLOSE:		return "BRACES_CLOSE";
	case MULTIPLICATION:	return "MULTIPLICATION";
	case DIVISION:			return "DIVISION";
	case ASSIGNMENT:		return "ASSIGNMENT";
	case ID:				return "ID";
	case INT_NUMBER:		return "INT_NUMBER";
	case REAL_NUMBER:		return "REAL_NUMBER";
	case UNDEFINED:			return "UNDEFINED";
	default:				return NULL;
	}
}




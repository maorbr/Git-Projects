#pragma once
#ifndef PARSER_H
#define PARSER_H
#include <stdio.h>
#include <stdlib.h>
#include"Token.h"

void InitializeFile(FILE* output);
void printSyntacticError(Token *CurrentToken, int Kind);
void parse_PROGRAM();
void parse_VAR_DEFINITIONS();
void parse_VAR_DEFINITION();
void parse_VAR_DEFINITIONS_1();
void parse_FUNC_DEFINITION();
void parse_TYPE();
void parse_VARIABLE();
void parse_VARIABLE_1();
void parse_VARIABLES_LIST();
void parse_VARIABLES_LIST_1();
void parse_FUNC_DEFINITIONS();
void parse_FUNC_DEFINITIONS_1();
void parse_RETURNED_TYPE();
void parse_PARAM_DEFINITIONS();
void parse_BLOCK();
void parse_STATEMENTS();
void parse_STATEMENTS_1();
void parse_STATEMENT();
void parse_STATEMENT_1();
void parse_STATEMENT_2();
void parse_EXPRESSION();
void parse_EXPRESSION_1();
void parse_PARAMETERS_LIST();

int match(int Token);
void printRule(int rule);
char* kindToText(int kind);
#endif
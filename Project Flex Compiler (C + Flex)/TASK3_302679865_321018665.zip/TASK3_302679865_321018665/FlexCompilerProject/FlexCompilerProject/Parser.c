﻿#include"parser.h"

Token *currentToken;
SymbolTable* curTable = NULL;
FILE *semanticFile, *syntacticFile;


void InitializeSemanticFile(FILE* output)
{
	semanticFile = output;
}

FILE* getSemanticFile() {
	return semanticFile;
}

void InitializeSyntacticFile(FILE* output)
{
	syntacticFile = output;
}


void printSyntacticError(Token *CurrentToken, int Kind)
{
	fprintf(syntacticFile, "Expected token of type '{%s}' at line: {%d},Actual token of type '{%s}', lexeme: '{%s}'.\n", kindToText(Kind), CurrentToken->lineNumber, kindToText(CurrentToken->kind), CurrentToken->lexeme);
}

//1.	PROGRAM -> program VAR_DEFINITIONS; STATEMENTS end FUNC_DEFINITIONS
void parse_PROGRAM()
{
	printf("Enter parse_PROGRAM\n");
	printRule(1);
	curTable = make_table(curTable);
	if (match(PROGRAM))
	{
		parse_VAR_DEFINITIONS();
		if (match(SEMICOLON))
		{
			parse_STATEMENTS(NULL);

			if (match(END))
			{
				parse_FUNC_DEFINITIONS();
				curTable = pop_table(curTable);
			}
			else
			{
				currentToken = recover_PROGRAM(END, currentToken);
			}
		}
		else
		{
			currentToken = recover_PROGRAM(SEMICOLON, currentToken);
		}
	}
	else
	{
		currentToken = recover_PROGRAM(PROGRAM, currentToken);
	}
	printf("Exit parse_PROGRAM\n");
}

//2.	VAR_DEFINITIONS -> VAR_DEFINITION VAR_DEFINITIONS_1
DataItem* parse_VAR_DEFINITIONS()
{
	DataItem *varDefinitions, *varDefinition, *varDefinitions_1;
	varDefinitions = initializeDataItem();

	printRule(2);
	varDefinition = parse_VAR_DEFINITION();
	varDefinitions_1 = parse_VAR_DEFINITIONS_1();

	varDefinitions->sizeOfParams = varDefinition->sizeOfParams + varDefinitions_1->sizeOfParams;
	varDefinitions->listOfParams = createList();
	addListToList(varDefinitions->listOfParams, varDefinition->listOfParams);
	addListToList(varDefinitions->listOfParams, varDefinitions_1->listOfParams);

	return varDefinitions;
}

//3.	VAR_DEFINITION -> TYPE VARIABLES_LIST
DataItem* parse_VAR_DEFINITION()
{
	DataItem *varDefinition, *type, *variablesList;
	varDefinition = initializeDataItem();

	printRule(3);

	type = parse_TYPE();
	variablesList = parse_VARIABLES_LIST(type);

	varDefinition->sizeOfParams = variablesList->sizeOfParams;
	varDefinition->listOfParams = createList();
	addListToList(varDefinition->listOfParams, variablesList->listOfParams);

	return varDefinition;
}

//4.	VAR_DEFINITIONS_1 -> ; VAR_DEFINITIONS
//5.	VAR_DEFINITIONS_1 -> ε
DataItem* parse_VAR_DEFINITIONS_1()
{
	DataItem *varDefinitions, *varDefinitions_1;
	varDefinitions_1 = initializeDataItem();

	currentToken = next_token();
	switch (currentToken->kind)
	{
	case SEMICOLON:
	{
		currentToken = next_token();
		switch (currentToken->kind)
		{
		case ID:
		case RETURN:
		case BRACES_OPEN:
		{
			printRule(5);
			currentToken = back_token();
			currentToken = back_token();

			varDefinitions_1->sizeOfParams = 0;
			varDefinitions_1->listOfParams = NULL;

			break;
		}
		case REAL:
		case INTEGER:
		{
			printRule(4);

			currentToken = back_token();
			varDefinitions = parse_VAR_DEFINITIONS();
			varDefinitions_1->sizeOfParams = varDefinitions->sizeOfParams;
			varDefinitions_1->listOfParams = createList();
			addListToList(varDefinitions_1->listOfParams, varDefinitions->listOfParams);
			break;
		}
		default:
		{
			fprintf(syntacticFile, "Syntax error in line %d: expected '%s'/'%s'/'%s'/'%s'/'%s', got '%s'\n",
				currentToken->lineNumber,
				kindToText(ID),
				kindToText(RETURN),
				kindToText(BRACES_OPEN),
				kindToText(REAL),
				kindToText(INTEGER),
				currentToken->lexeme);

			while (!follow_VAR_DEFINITIONS_1(currentToken->kind) && currentToken->kind != EOF_TOKEN)
				currentToken = next_token();
			if (currentToken->kind == EOF_TOKEN) {
				printf("Exit with Error 4,5");
				exit(1);
			}
			else
			{
				currentToken = back_token();
			}
			break;
		}
		}
		break;
	}
	case PARENTHESES_CLOSE:
	{
		printRule(5);
		currentToken = back_token();

		varDefinitions_1->sizeOfParams = 0;
		varDefinitions_1->listOfParams = NULL;
		break;
	}
	default:
	{
		fprintf(syntacticFile, "Syntax error in line %d: expected '%s'/'%s', got '%s'\n",
			currentToken->lineNumber,
			kindToText(SEMICOLON),
			kindToText(PARENTHESES_CLOSE),
			currentToken->lexeme);
		while (!follow_VAR_DEFINITIONS_1(currentToken->kind) && currentToken->kind != EOF_TOKEN)
			currentToken = next_token();
		if (currentToken->kind == EOF_TOKEN) {
			printf("Exit with Error 4,5");
			exit(1);
		}
		else
		{
			currentToken = back_token();
			break;
		}
	}
	}
	return varDefinitions_1;
}

//6. FUNC_DEFINITION -> RETURNED_TYPE id (PARAM_DEFINITIONS) BLOCK 
void parse_FUNC_DEFINITION()
{
	DataItem *returnedType, *paramDefinitions, *idTableEntry;

	printRule(6);

	returnedType = parse_RETURNED_TYPE();

	if (currentToken->kind == ID)
	{
		idTableEntry = insert(curTable, currentToken->lexeme);
	}
	else {
		idTableEntry = initializeDataItem();
	}

	if (match(ID))
	{
		if (match(PARENTHESES_OPEN))
		{
			paramDefinitions = parse_PARAM_DEFINITIONS();

			if (!idTableEntry) {
				fprintf(semanticFile, "\nERROR: duplicated declaration of the same name: %s within same scope in line %d\n", currentToken->lexeme, currentToken->lineNumber);
			}
			else {
				idTableEntry->size = -1;
				idTableEntry->varType = NULL_type;
				idTableEntry->returnType = returnedType->returnType;
				idTableEntry->sizeOfParams = paramDefinitions->sizeOfParams;
				idTableEntry->listOfParams = createList();
				addListToList(idTableEntry->listOfParams, paramDefinitions->listOfParams);
			}
			if (match(PARENTHESES_CLOSE))
			{
				parse_BLOCK(returnedType);
			}
			else
			{
				currentToken = recover_FUNC_DEFINITION(PARENTHESES_CLOSE, currentToken);
			}
		}
		else
		{
			currentToken = recover_FUNC_DEFINITION(PARENTHESES_OPEN, currentToken);
		}
	}
	else
	{
		currentToken = recover_FUNC_DEFINITION(ID, currentToken);
	}
}

//7.	FUNC_DEFINITIONS -> FUNC_DEFINITION FUNC_DEFINITIONS_1
void parse_FUNC_DEFINITIONS()
{
	printRule(7);
	parse_FUNC_DEFINITION();
	parse_FUNC_DEFINITIONS_1();
}

//8.	FUNC_DEFINITIONS_1 -> FUNC_DEFINITION FUNC_DEFINITIONS_1
//9.	FUNC_DEFINITIONS_1 -> ε
void parse_FUNC_DEFINITIONS_1()
{
	currentToken = next_token();
	switch (currentToken->kind)
	{
	case VOID:
	case REAL:
	case INTEGER:
	{
		printRule(8);
		currentToken = back_token();
		parse_FUNC_DEFINITION();
		parse_FUNC_DEFINITIONS_1();
		break;
	}
	case EOF_TOKEN:
	{
		printRule(9);
		currentToken = back_token();
		break;
	}
	default:
	{
		fprintf(syntacticFile, "Syntax error in line %d: expected '%s'/'%s'/'%s'/'%s', got '%s'\n",
			currentToken->lineNumber,
			kindToText(VOID),
			kindToText(REAL),
			kindToText(INTEGER),
			kindToText(EOF_TOKEN),
			currentToken->lexeme);
		while (!follow_FUNC_DEFINITION(currentToken->kind) && currentToken->kind != EOF_TOKEN)
			currentToken = next_token();
		if (currentToken->kind == EOF_TOKEN) {
			printf("Exit with Error 8,9");
			exit(1);
		}
		else {
			currentToken = back_token();
			parse_FUNC_DEFINITIONS_1();
			break;
		}
	}
	}
}

//10.	RETURNED_TYPE -> void
//11.	RETURNED_TYPE -> TYPE
DataItem* parse_RETURNED_TYPE()
{
	DataItem *returnedType, *type;

	returnedType = initializeDataItem();

	currentToken = next_token();
	switch (currentToken->kind)
	{
	case VOID:
	{
		printRule(10);
		returnedType->returnType = VOID_type;
		break;
	}
	case REAL:
	case INTEGER:
	{
		printRule(11);
		currentToken = back_token();

		type = parse_TYPE();
		returnedType->returnType = type->varType;

		break;
	}
	default:
	{
		fprintf(syntacticFile, "Syntax error in line %d: expected '%s'/'%s'/'%s', got '%s'\n",
			currentToken->lineNumber,
			kindToText(VOID),
			kindToText(REAL),
			kindToText(INTEGER),
			currentToken->lexeme);
		while (!follow_RETURNED_TYPE(currentToken->kind) && currentToken->kind != EOF_TOKEN)
			currentToken = next_token();
		if (currentToken->kind == EOF_TOKEN) {
			printf("Exit with Error 10,11");
			exit(1);
		}
		else {
			currentToken = back_token();
			break;
		}
	}
	}

	return returnedType;
}

//12. PARAM_DEFINITIONS -> VAR_DEFINITIONS
//13. PARAM_DEFINITIONS -> ε
DataItem* parse_PARAM_DEFINITIONS()
{
	DataItem *paramDefinitions, *varDefinitions;

	paramDefinitions = initializeDataItem();

	currentToken = next_token();
	switch (currentToken->kind)
	{
	case REAL:
	case INTEGER:
	{
		printRule(12);
		currentToken = back_token();

		varDefinitions = parse_VAR_DEFINITIONS();

		paramDefinitions->sizeOfParams = varDefinitions->sizeOfParams;
		paramDefinitions->listOfParams = createList();
		addListToList(paramDefinitions->listOfParams, varDefinitions->listOfParams);

		break;
	}
	case PARENTHESES_CLOSE:
	{
		printRule(13);
		currentToken = back_token();
		paramDefinitions->sizeOfParams = 0;
		paramDefinitions->listOfParams = NULL;
		break;
	}
	default:
	{
		fprintf(syntacticFile, "Syntax error in line %d: expected '%s'/'%s'/'%s', got '%s'\n",
			currentToken->lineNumber,
			kindToText(REAL),
			kindToText(INTEGER),
			kindToText(PARENTHESES_CLOSE),
			currentToken->lexeme);
		while (!follow_PARAM_DEFINITIONS(currentToken->kind) && currentToken->kind != EOF_TOKEN)
			currentToken = next_token();
		if (currentToken->kind == EOF_TOKEN) {
			printf("Exit with Error 12,13");
			exit(1);
		}
		else {
			currentToken = back_token();
			break;
		}
	}
	}
	return paramDefinitions;
}

//14.	BLOCK -> { VAR_DEFINITIONS; STATEMENTS }
void parse_BLOCK(DataItem* dataItem)
{
	DataItem *block;

	block = initializeDataItem();
	block->returnType = dataItem->returnType;

	printRule(14);
	if (match(BRACES_OPEN))
	{
		curTable = make_table(curTable);

		parse_VAR_DEFINITIONS();

		if (match(SEMICOLON))
		{
			parse_STATEMENTS(block);
			curTable = pop_table(curTable);

			if (!match(BRACES_CLOSE))
			{
				currentToken = recover_BLOCK(BRACES_CLOSE, currentToken);
			}
		}
		else
		{
			currentToken = recover_BLOCK(SEMICOLON, currentToken);
		}
	}
	else
	{
		currentToken = recover_BLOCK(BRACES_OPEN, currentToken);
	}
}

//15.	STATEMENTS -> STATEMENT; STATEMENTS_1
void parse_STATEMENTS(DataItem* dataItem)
{
	DataItem *statements;

	statements = initializeDataItem();

	if (dataItem) {
		statements->returnType = dataItem->returnType;
	}

	printRule(15);

	parse_STATEMENT(statements);

	if (match(SEMICOLON))
	{
		parse_STATEMENTS_1(statements);
	}
	else
	{
		currentToken = recover_STATEMENTS(SEMICOLON, currentToken);
	}
}
//16.	STATEMENTS_1 -> STATEMENTS
//17.	STATEMENTS_1 -> ε
void parse_STATEMENTS_1(DataItem* dataItem)
{
	DataItem *statements_1;

	statements_1 = initializeDataItem();
	statements_1->returnType = dataItem->returnType;

	currentToken = next_token();
	switch (currentToken->kind)
	{
	case RETURN:
	case ID:
	case BRACES_OPEN:
	{
		printRule(16);
		currentToken = back_token();
		parse_STATEMENTS(statements_1);
		break;
	}
	case END:
	case BRACES_CLOSE:
	{
		printRule(17);
		currentToken = back_token();
		break;
	}
	default:
	{
		fprintf(syntacticFile, "Syntax error in line %d: expected '%s'/'%s'/'%s'/'%s'/'%s', got '%s'\n",
			currentToken->lineNumber,
			kindToText(RETURN),
			kindToText(ID),
			kindToText(BRACES_OPEN),
			kindToText(END),
			kindToText(BRACES_CLOSE),
			currentToken->lexeme);
		while (!follow_STATEMENTS_1(currentToken->kind) && currentToken->kind != EOF_TOKEN)
			currentToken = next_token();
		if (currentToken->kind == EOF_TOKEN) {
			printf("Exit with Error 16,17");
			exit(1);
		}
		else {
			currentToken = back_token();
			break;
		}
	}
	}
}

//18.	STATEMENT -> BLOCK
//19.	STATEMENT -> return STATEMENT_1
//20.	STATEMENT -> id STATEMENT_2
void parse_STATEMENT(DataItem* dataItem)
{
	DataItem *statement, *statement_1, *statement_2, *idTableEntry;
	int line, IDsize, IDsizeOfParams;
	list *IDlistOfParams;
	types IDtype;

	statement = initializeDataItem();
	statement->returnType = dataItem->returnType;

	currentToken = next_token();
	switch (currentToken->kind)
	{
	case BRACES_OPEN:
	{
		printRule(18);
		currentToken = back_token();
		parse_BLOCK(statement);
		break;
	}
	case RETURN:
	{
		printRule(19);
		statement_1 = parse_STATEMENT_1();
		if (statement->returnType != statement_1->varType)
			fprintf(semanticFile, "ERROR: return type is incompatible at line: %d.\n", currentToken->lineNumber);
		break;
	}
	case ID:
	{
		printRule(20);
		line = currentToken->lineNumber;
		idTableEntry = find(curTable, currentToken->lexeme, line);
		statement_2 = parse_STATEMENT_2();
		if (idTableEntry) {
			IDtype = idTableEntry->varType;
			IDsize = idTableEntry->size;
			IDsizeOfParams = idTableEntry->sizeOfParams;
			IDlistOfParams = idTableEntry->listOfParams;

			if (IDtype == NULL_type)
			{
				if (statement_2->size == -1 && (statement_2->varType == NULL_type || statement_2->varType == VOID_type)) 
				{ 
					if (IDsizeOfParams != statement_2->sizeOfParams) 
					{
						fprintf(semanticFile, "ERROR: amount of parameters in function call identifier: \"%s\" are not match to function definition, at line: %d.\n", idTableEntry->id_name, line);
					}
					else if (!equalListToList(IDlistOfParams, statement_2->listOfParams)) 
					{
						fprintf(semanticFile, "ERROR:  types of parameters in function call identifier: \"%s\" are not match function definition, at line: %d.\n", idTableEntry->id_name, line);
					}
				}
				else if (statement_2->sizeOfParams == -1)
				{
					if (statement_2->size > -1) 
					{
						fprintf(semanticFile, "ERROR: identifier: \"%s\" is not refer to entire array type, at line: %d.\n", idTableEntry->id_name, line);
					}
					else 
					{
						fprintf(semanticFile, "ERROR: trying assignment to a function type, identifier: \"%s\", at line: %d.\n", idTableEntry->id_name, line);
					}
				}
			}
			else if (IDtype == INTEGER_type || IDtype == REAL_type)
			{
				if (IDsize > -1) 
				{
					if (statement_2->size == -1 && (statement_2->varType == NULL_type || statement_2->varType == VOID_type)) 
					{
						fprintf(semanticFile, "ERROR: identifier: \"%s\" is not kind of function type, at line: %d.\n", idTableEntry->id_name, line);
					}
					else if (statement_2->sizeOfParams == -1)
					{
						if (statement_2->size > -1) 
						{
							if (statement_2->size >= IDsize) 
							{
								fprintf(semanticFile, "ERROR: access to array: \"%s\", at index %d is illegal, index is out of array bounds, at line: %d.\n", idTableEntry->id_name, statement_2->size, line);
							}
						}
						else if (statement_2->size == -1) 
						{
							fprintf(semanticFile, "ERROR: assignment of type array is illegal, identifier: \"%s\", at line: %d.\n", idTableEntry->id_name, line);
						}
					}
				}
				else
				{
					if (statement_2->size == -1 && (statement_2->varType == NULL_type || statement_2->varType == VOID_type) && statement_2->sizeOfParams > -1) 
					{
						fprintf(semanticFile, "ERROR: identifier: \"%s\" is not kind of function type, at line: %d.\n", idTableEntry->id_name, line);
					}
					else if (statement_2->sizeOfParams == -1)
					{
						if (statement_2->size > -1) 
						{
							fprintf(semanticFile, "ERROR: identifier: \"%s\" is not kind of array type, at line: %d.\n", idTableEntry->id_name, line);
						}
						else if (statement_2->varType != IDtype && IDtype != REAL_type) 
						{
							fprintf(semanticFile, "ERROR: incorrect assignment types are different, at line:%d.\n", currentToken->lineNumber);
						}
					}
				}
			}
			break;
		}
	default:
	{
		fprintf(syntacticFile, "Syntax error in line %d: expected '%s'/'%s'/'%s', got '%s'\n",
			currentToken->lineNumber,
			kindToText(BRACES_OPEN),
			kindToText(RETURN),
			kindToText(ID),
			currentToken->lexeme);
		while (!follow_STATEMENT(currentToken->kind) && currentToken->kind != EOF_TOKEN)
			currentToken = next_token();
		if (currentToken->kind == EOF_TOKEN) {
			printf("Exit with Error 18,19,20");
			exit(1);
		}
		else {
			currentToken = back_token();
			break;
		}
	}
	}
	}
}

//21.	STATEMENT_1 -> EXPRESSION
//22.	STATEMENT_1 -> ε
DataItem* parse_STATEMENT_1()
{
	DataItem *statement_1, *expression;

	statement_1 = initializeDataItem();

	currentToken = next_token();
	switch (currentToken->kind)
	{
	case INT_NUMBER:
	case REAL_NUMBER:
	case ID:
	{
		printRule(21);
		currentToken = back_token();

		expression = parse_EXPRESSION();
		statement_1->varType = expression->varType;
		break;
	}
	case SEMICOLON:
	{
		printRule(22);
		currentToken = back_token();

		statement_1->varType = VOID_type;

		break;
	}
	default:
	{
		fprintf(syntacticFile, "Syntax error in line %d: expected '%s'/'%s'/'%s'/'%s', got '%s'\n",
			currentToken->lineNumber,
			kindToText(INT_NUMBER),
			kindToText(REAL_NUMBER),
			kindToText(ID),
			kindToText(SEMICOLON),
			currentToken->lexeme);
		while (!follow_STATEMENT_1(currentToken->kind) && currentToken->kind != EOF_TOKEN)
			currentToken = next_token();
		if (currentToken->kind == EOF_TOKEN) {
			printf("Exit with Error 16,17");
			exit(1);
		}
		else {
			currentToken = back_token();
			break;
		}
	}
	}
	return statement_1;
}

//23.	STATEMENT_2 -> VARIABLE_1 = EXPRESSION
//24.	STATEMENT_2 -> (PARAMETERS_LIST)
DataItem* parse_STATEMENT_2()
{
	DataItem *statement_2, *expression, *parametersList, *variable_1;

	statement_2 = initializeDataItem();

	currentToken = next_token();
	switch (currentToken->kind)
	{
	case ASSIGNMENT:
	case BRACKETS_OPEN:
	{
		printRule(23);
		currentToken = back_token();
		variable_1 = parse_VARIABLE_1();
		if (match(ASSIGNMENT))
		{
			expression = parse_EXPRESSION();
			statement_2->varType = expression->varType;
			statement_2->size = variable_1->size;
			statement_2->sizeOfParams = -1;
			statement_2->listOfParams = NULL;
		}
		else
		{
			currentToken = recover_STATEMENT_2(ASSIGNMENT, currentToken);
		}
		break;
	}
	case PARENTHESES_OPEN:
	{
		printRule(24);

		parametersList = parse_PARAMETERS_LIST();

		statement_2->varType = parametersList->varType;
		statement_2->size = -1;
		statement_2->sizeOfParams = parametersList->sizeOfParams;
		statement_2->listOfParams = createList();
		addListToList(statement_2->listOfParams, parametersList->listOfParams);

		if (!match(PARENTHESES_CLOSE))
		{
			currentToken = recover_STATEMENT_2(PARENTHESES_CLOSE, currentToken);
		}
		break;
	}
	default:
	{
		fprintf(syntacticFile, "Syntax error in line %d: expected '%s'/'%s'/'%s', got '%s'\n",
			currentToken->lineNumber,
			kindToText(BRACKETS_OPEN),
			kindToText(PARENTHESES_OPEN),
			kindToText(ASSIGNMENT),
			currentToken->lexeme);
		while (!follow_STATEMENT_2(currentToken->kind) && currentToken->kind != EOF_TOKEN)
			currentToken = next_token();
		if (currentToken->kind == EOF_TOKEN) {
			printf("Exit with Error 23,24");
			exit(1);
		}
		else {
			currentToken = back_token();
			break;
		}
	}
	}
	return statement_2;
}

//25.	EXPRESSION-> int_number
//26.	EXPRESSION-> real_number
//27.	EXPRESSION-> id EXPRESSION_1
DataItem* parse_EXPRESSION()
{
	DataItem *expression, *expression_1, *idTableEntry;
	int IDsize, line;
	types	IDtype;

	expression = initializeDataItem();

	currentToken = next_token();
	switch (currentToken->kind)
	{
	case INT_NUMBER:
	{
		printRule(25);
		expression->varType = INTEGER_type;
		break;
	}
	case REAL_NUMBER:
	{
		printRule(26);
		expression->varType = REAL_type;
		break;
	}
	case ID:
	{
		printRule(27);

		line = currentToken->lineNumber;
		idTableEntry = find(curTable, currentToken->lexeme, line);
		expression_1 = parse_EXPRESSION_1();
		if (idTableEntry)
		{
			IDtype = idTableEntry->varType;

			IDsize = idTableEntry->size;
			if (expression_1->size == -1) {
				if (IDsize > -1) {
					fprintf(semanticFile, "ERROR: expression can't refer to entire array, identifier: \"%s\" at line %d.\n", idTableEntry->id_name, line);
				}
				else if (IDtype == INTEGER_type && expression_1->varType == INTEGER_type) {
					expression->varType = INTEGER_type;
				}
				else if (IDtype == REAL_type || expression_1->varType == REAL_type) {
					expression->varType = REAL_type;
				}
			}
			else
			{
				if (expression_1->size < IDsize) {
					expression->varType = IDtype;
				}
				else {
					if (IDsize == -1) {
						fprintf(semanticFile, "ERROR: identifier: \"%s\" is not kind of array type, at line: %d.\n", idTableEntry->id_name, line);
					}
					else
					{
						fprintf(semanticFile, "ERROR: array identifier: \"%s\" index is out of bounds, at line: %d.\n", idTableEntry->id_name, line);
					}
				}
			}
		}
		break;
	}
	default:
	{
		fprintf(syntacticFile, "Syntax error in line %d: expected '%s'/'%s'/'%s', got '%s'\n",
			currentToken->lineNumber,
			kindToText(INT_NUMBER),
			kindToText(REAL_NUMBER),
			kindToText(ID),
			currentToken->lexeme);
		while (!follow_EXPRESSION(currentToken->kind) && currentToken->kind != EOF_TOKEN)
			currentToken = next_token();
		if (currentToken->kind == EOF_TOKEN) {
			printf("Exit with Error 25,26,27");
			exit(1);
		}
		else {
			currentToken = back_token();
			break;
		}
	}
	}
	return expression;
}

//28.	EXPRESSION_1 -> VARIABLE_1
//29.	EXPRESSION_1 -> <ar_op> * EXPRESSION
//40.	EXPRESSION_1 -> <ar_op> / EXPRESSION
//41.	EXPRESSION_1 -> <ar_op> = EXPRESSION
DataItem* parse_EXPRESSION_1()
{
	DataItem *expression_1, *variable_1, *expression;

	expression_1 = initializeDataItem();

	currentToken = next_token();
	switch (currentToken->kind)
	{
	case BRACKETS_OPEN:
	{
		printRule(28);
		currentToken = back_token();
		variable_1 = parse_VARIABLE_1();
		expression_1->size = variable_1->size;
		break;
	}
	case MULTIPLICATION:
	{
		printRule(29);
		expression = parse_EXPRESSION();
		expression_1->varType = expression->varType;
		expression_1->size = -1;
		break;
	}
	case DIVISION:
	{
		printRule(40);
		expression = parse_EXPRESSION();
		expression_1->varType = expression->varType;
		expression_1->size = -1;
		break;
	}
	case ASSIGNMENT:
	{
		printRule(41);
		currentToken = back_token();
		expression = parse_EXPRESSION();
		expression_1->varType = expression->varType;
		expression_1->size = -1;
		break;
	}
	case SEMICOLON:
	{
		printRule(28);
		currentToken = back_token();
		break;
	}
	default:
	{
		fprintf(syntacticFile, "Syntax error in line %d: expected '%s'/'%s'/'%s'/'%s', got '%s'\n",
			currentToken->lineNumber,
			kindToText(BRACKETS_OPEN),
			kindToText(MULTIPLICATION),
			kindToText(DIVISION),
			kindToText(ASSIGNMENT),
			currentToken->lexeme);
		while (!follow_EXPRESSION_1(currentToken->kind) && currentToken->kind != EOF_TOKEN)
			currentToken = next_token();
		if (currentToken->kind == EOF_TOKEN) {
			printf("Exit with Error 28,29,40,41");
			exit(1);
		}
		else {
			currentToken = back_token();
			break;
		}
	}
	}
	return expression_1;
}

//30. PARAMETERS_LIST -> VARIABLES_LIST
//31. PARAMETERS_LIST -> ε
DataItem* parse_PARAMETERS_LIST()
{
	DataItem *parametersList, *variablesList;
	parametersList = initializeDataItem();

	currentToken = next_token();
	switch (currentToken->kind)
	{
	case ID:
	{
		printRule(30);
		currentToken = back_token();

		variablesList = parse_VARIABLES_LIST(parametersList);

		parametersList->sizeOfParams = variablesList->sizeOfParams;
		parametersList->listOfParams = createList();
		addListToList(parametersList->listOfParams, variablesList->listOfParams);
		break;
	}
	case PARENTHESES_CLOSE:
	{
		printRule(31);
		currentToken = back_token();

		parametersList->varType = VOID_type;
		parametersList->sizeOfParams = 0;
		parametersList->listOfParams = NULL;
		break;
	}
	default:
	{
		fprintf(syntacticFile, "Syntax error in line %d: expected '%s'/'%s', got '%s'\n",
			currentToken->lineNumber,
			kindToText(ID),
			kindToText(PARENTHESES_CLOSE),
			currentToken->lexeme);
		while (!follow_PARAMETERS_LIST(currentToken->kind) && currentToken->kind != EOF_TOKEN)
			currentToken = next_token();
		if (currentToken->kind == EOF_TOKEN) {
			printf("Exit with Error 30,31");
			exit(1);
		}
		else {
			currentToken = back_token();
			break;
		}
	}
	}
	return parametersList;
}

//32.	TYPE-> real
//33.	TYPE-> integer
DataItem* parse_TYPE()
{
	DataItem *type;
	type = initializeDataItem();

	currentToken = next_token();
	switch (currentToken->kind)
	{
	case REAL:
	{
		printRule(32);
		type->varType = REAL_type;
		break;
	}
	case INTEGER:
	{
		printRule(33);
		type->varType = INTEGER_type;
		break;
	}
	default:
	{
		fprintf(syntacticFile, "Syntax error in line %d: expected '%s'/'%s', got '%s'\n", currentToken->lineNumber, kindToText(INTEGER), kindToText(REAL), currentToken->lexeme);
		while (!follow_TYPE(currentToken->kind) && currentToken->kind != EOF_TOKEN)
			currentToken = next_token();
		if (currentToken->kind == EOF_TOKEN) {
			printf("Exit with Error 32,33");
		}
		else {
			currentToken = back_token();
		}
		break;
	}
	}
	return type;
}

//34.	VARIABLE -> id VARIABLE_1
DataItem* parse_VARIABLE(DataItem* dataItem)
{
	DataItem *variable, *idTableEntry, *variable_1;
	char *IDname = (char*)malloc(sizeof(char) * 50);

	variable = initializeDataItem();
	variable->varType = dataItem->varType;

	if (match(ID))
	{
		printRule(34);

		IDname = currentToken->lexeme;
		variable_1 = parse_VARIABLE_1();
		if (variable->varType != NULL_type) {
			idTableEntry = insert(curTable, IDname);
			if (!idTableEntry) {
				fprintf(semanticFile, "ERROR: duplicated declaration of the same name: %s within same scope in line %d\n", currentToken->lexeme, currentToken->lineNumber);
			}
			else {
				idTableEntry->varType = variable->varType;

				idTableEntry->size = variable_1->size;
				idTableEntry->sizeOfParams = -1;
			}
		}
		else {
			idTableEntry = find(curTable, currentToken->lexeme, currentToken->lineNumber);
		}
		if (idTableEntry) {
			variable->sizeOfParams = 1;
			variable->listOfParams = createList();
			addLastToList(variable->listOfParams, ((varTypeItem *)idTableEntry));
		}
		else {
			variable->sizeOfParams = 0;
			variable->listOfParams = NULL;
		}
	}
	else
	{
		currentToken = recover_VARIABLE(ID, currentToken);
	}
	return variable;
}

//35.	VARIABLE_1 -> [int_number]
//36.	VARIABLE_1 -> ε 
DataItem* parse_VARIABLE_1()
{
	DataItem *variable_1;
	variable_1 = initializeDataItem();

	currentToken = next_token();
	switch (currentToken->kind)
	{
	case BRACKETS_OPEN:
	{
		printRule(35);

		if (match(INT_NUMBER))
		{
			variable_1->size = atoi(currentToken->lexeme);

			if (match(BRACKETS_CLOSE))
			{
			}
			else
			{
				currentToken = recover_VARIABLE_1(BRACKETS_CLOSE, currentToken);
			}
		}
		else
		{
			currentToken = recover_VARIABLE_1(INT_NUMBER, currentToken);
		}
		break;
	}
	case COMMA:
	case SEMICOLON:
	case ASSIGNMENT:
	case PARENTHESES_CLOSE:
	{
		printRule(36);
		currentToken = back_token();
		break;
	}
	default:
	{
		fprintf(syntacticFile, "Syntax error in line %d: expected '%s'/'%s'/'%s'/'%s'/'%s', got '%s'\n",
			currentToken->lineNumber,
			kindToText(BRACKETS_OPEN),
			kindToText(COMMA),
			kindToText(SEMICOLON),
			kindToText(ASSIGNMENT),
			kindToText(PARENTHESES_CLOSE),
			currentToken->lexeme);
		while (!follow_VARIABLE_1(currentToken->kind) && currentToken->kind != EOF_TOKEN)
			currentToken = next_token();
		if (currentToken->kind == EOF_TOKEN) {
			printf("Exit with Error 35,36");
			exit(1);
		}
		else {
			currentToken = back_token();
			break;
		}
	}
	}
	return variable_1;
}

//37.	VARIABLES_LIST -> VARIABLE VARIABLES_LIST_1
DataItem* parse_VARIABLES_LIST(DataItem* dataItem)
{
	DataItem *variableList, *variable, *variableList_1;
	variableList = initializeDataItem();
	variableList->varType = dataItem->varType;

	printRule(37);

	variable = parse_VARIABLE(variableList);
	variableList_1 = parse_VARIABLES_LIST_1(variableList);

	variableList->sizeOfParams = variable->sizeOfParams + variableList_1->sizeOfParams;
	variableList->listOfParams = createList();
	addListToList(variableList->listOfParams, variable->listOfParams);
	addListToList(variableList->listOfParams, variableList_1->listOfParams);

	return variableList;
}

//38.	VARIABLES_LIST_1 -> , VARIABLE VARIABLES_LIST_1
//39.	VARIABLES_LIST_1 -> ε 
DataItem* parse_VARIABLES_LIST_1(DataItem* dataItem)
{
	DataItem *variable, *variableList_1_right, *variableList_1_left;

	variableList_1_left = initializeDataItem();

	variableList_1_left->varType = dataItem->varType;

	currentToken = next_token();
	switch (currentToken->kind)
	{
	case COMMA:
	{
		printRule(38);

		variable = parse_VARIABLE(variableList_1_left);
		variableList_1_right = parse_VARIABLES_LIST_1(variableList_1_left);

		variableList_1_left->sizeOfParams = variable->sizeOfParams + variableList_1_right->sizeOfParams;
		variableList_1_left->listOfParams = createList();
		addListToList(variableList_1_left->listOfParams, variable->listOfParams);
		addListToList(variableList_1_left->listOfParams, variableList_1_right->listOfParams);

		break;
	}
	case SEMICOLON:
	case PARENTHESES_CLOSE:
	{
		printRule(39);
		currentToken = back_token();

		variableList_1_left->sizeOfParams = 0;
		variableList_1_left->listOfParams = NULL;

		break;
	}
	default:
	{
		fprintf(syntacticFile, "Syntax error in line %d: expected '%s'/'%s'/'%s', got '%s'\n",
			currentToken->lineNumber,
			kindToText(COMMA),
			kindToText(SEMICOLON),
			kindToText(PARENTHESES_CLOSE),
			currentToken->lexeme);
		while (!follow_VARIABLES_LIST_1(currentToken->kind) && currentToken->kind != EOF_TOKEN)
			currentToken = next_token();
		if (currentToken->kind == EOF_TOKEN) {
			printf("Exit with Error 38,39");
			exit(1);
		}
		else
		{
			currentToken = back_token();
			break;
		}
	}
	}
	return variableList_1_left;
}

int match(int token) {
	currentToken = next_token();
	if (token == currentToken->kind)
	{
		return 1;
	}
	return 0;
}

void printRule(int rule)
{
	switch (rule)
	{
	case 1: {	fprintf(syntacticFile, "Rule (PROGRAM -> program VAR_DEFINITIONS; STATEMENTS end FUNC_DEFINITIONS) \n");
		break; }
	case 2: {	fprintf(syntacticFile, "Rule (VAR_DEFINITIONS -> VAR_DEFINITION VAR_DEFINITIONS_1) \n");
		break; }
	case 3: {	fprintf(syntacticFile, "Rule (VAR_DEFINITION -> TYPE VARIABLES_LIST) \n");
		break; }
	case 4: {	fprintf(syntacticFile, "Rule (VAR_DEFINITIONS_1 -> ; VAR_DEFINITIONS) \n");
		break; }
	case 5: {	fprintf(syntacticFile, "Rule (VAR_DEFINITIONS_1 -> epsilon) \n");
		break; }
	case 6: {	fprintf(syntacticFile, "Rule (FUNC_DEFINITION -> RETURNED_TYPE id (PARAM_DEFINITIONS) BLOCK) \n");
		break; }
	case 7: {	fprintf(syntacticFile, "Rule (FUNC_DEFINITIONS -> FUNC_DEFINITION FUNC_DEFINITIONS_1) \n");
		break; }
	case 8: {	fprintf(syntacticFile, "Rule (FUNC_DEFINITIONS_1 -> FUNC_DEFINITION FUNC_DEFINITIONS_1) \n");
		break; }
	case 9: {	fprintf(syntacticFile, "Rule (FUNC_DEFINITIONS_1 -> epsilon) \n");
		break; }
	case 10: { fprintf(syntacticFile, "Rule (RETURNED_TYPE -> void) \n");
		break; }
	case 11: { fprintf(syntacticFile, "Rule (RETURNED_TYPE -> TYPE) \n");
		break; }
	case 12: { fprintf(syntacticFile, "Rule (PARAM_DEFINITIONS -> VAR_DEFINITIONS) \n");
		break; }
	case 13: { fprintf(syntacticFile, "Rule (PARAM_DEFINITIONS -> epsilon) \n");
		break; }
	case 14: { fprintf(syntacticFile, "Rule (BLOCK -> { VAR_DEFINITIONS; STATEMENTS }) \n");
		break; }
	case 15: { fprintf(syntacticFile, "Rule (STATEMENTS -> STATEMENT; STATEMENTS_1) \n");
		break; }
	case 16: { fprintf(syntacticFile, "Rule (STATEMENTS_1 -> STATEMENTS) \n");
		break; }
	case 17: { fprintf(syntacticFile, "Rule (STATEMENTS_1 -> epsilon) \n");
		break; }
	case 18: { fprintf(syntacticFile, "Rule (STATEMENT -> BLOCK) \n");
		break; }
	case 19: { fprintf(syntacticFile, "Rule (STATEMENT -> return STATEMENT_1) \n");
		break; }
	case 20: { fprintf(syntacticFile, "Rule (STATEMENT -> id STATEMENT_2) \n");
		break; }
	case 21: { fprintf(syntacticFile, "Rule (STATEMENT_1 -> EXPRESSION) \n");
		break; }
	case 22: { fprintf(syntacticFile, "Rule (STATEMENT_1 -> epsilon) \n");
		break; }
	case 23: { fprintf(syntacticFile, "Rule (STATEMENT_2 -> VARIABLE_1 = EXPRESSION) \n");
		break; }
	case 24: { fprintf(syntacticFile, "Rule (STATEMENT_2 -> (PARAMETERS_LIST)) \n");
		break; }
	case 25: { fprintf(syntacticFile, "Rule (EXPRESSION-> int_number) \n");
		break; }
	case 26: { fprintf(syntacticFile, "Rule (EXPRESSION-> real_number) \n");
		break; }
	case 27: { fprintf(syntacticFile, "Rule (EXPRESSION-> id EXPRESSION_1) \n");
		break; }
	case 28: { fprintf(syntacticFile, "Rule (EXPRESSION_1 -> VARIABLE_1) \n");
		break; }
	case 29: { fprintf(syntacticFile, "Rule (EXPRESSION_1 -> * EXPRESSION) \n");
		break; }
	case 30: { fprintf(syntacticFile, "Rule (PARAMETERS_LIST -> VARIABLES_LIST) \n");
		break; }
	case 31: { fprintf(syntacticFile, "Rule (PARAMETERS_LIST -> epsilon) \n");
		break; }
	case 32: { fprintf(syntacticFile, "Rule (TYPE-> real) \n");
		break; }
	case 33: { fprintf(syntacticFile, "Rule (TYPE-> integer) \n");
		break; }
	case 34: { fprintf(syntacticFile, "Rule (VARIABLE -> id VARIABLE_1) \n");
		break; }
	case 35: { fprintf(syntacticFile, "Rule (VARIABLE_1 -> [int_number]) \n");
		break; }
	case 36: { fprintf(syntacticFile, "Rule (VARIABLE_1 -> epsilon) \n");
		break; }
	case 37: { fprintf(syntacticFile, "Rule (VARIABLES_LIST -> VARIABLE VARIABLES_LIST_1) \n");
		break; }
	case 38: { fprintf(syntacticFile, "Rule (VARIABLES_LIST_1 -> , VARIABLE VARIABLES_LIST_1) \n");
		break; }
	case 39: { fprintf(syntacticFile, "Rule (VARIABLES_LIST_1 -> epsilon) \n");
		break; }
	case 40: { fprintf(syntacticFile, "Rule (EXPRESSION_1 -> / EXPRESSION) \n");
		break; }
	case 41: { fprintf(syntacticFile, "Rule (EXPRESSION_1 -> = EXPRESSION) \n");
		break; }
	}
}

char* kindToText(int kind)
{
	switch (kind)
	{
	case EOF_TOKEN:			return "EOF_TOKEN";
	case PROGRAM:			return "PROGRAM";
	case END:				return "END";
	case REAL:				return "REAL";
	case INTEGER:			return "INTEGER";
	case VOID:				return "VOID";
	case RETURN:			return "RETURN";
	case SEMICOLON:			return "SEMICOLON";
	case COMMA:				return "COMMA";
	case PARENTHESES_OPEN:	return "PARENTHESES_OPEN";
	case PARENTHESES_CLOSE:	return "PARENTHESES_CLOSE";
	case BRACKETS_OPEN:		return "BRACKETS_OPEN";
	case BRACKETS_CLOSE:	return "BRACKETS_CLOSE";
	case BRACES_OPEN:	    return "BRACES_OPEN";
	case BRACES_CLOSE:		return "BRACES_CLOSE";
	case MULTIPLICATION:	return "MULTIPLICATION";
	case DIVISION:			return "DIVISION";
	case ASSIGNMENT:		return "ASSIGNMENT";
	case ID:				return "ID";
	case INT_NUMBER:		return "INT_NUMBER";
	case REAL_NUMBER:		return "REAL_NUMBER";
	case UNDEFINED:			return "UNDEFINED";
	default:				return NULL;
	}
}





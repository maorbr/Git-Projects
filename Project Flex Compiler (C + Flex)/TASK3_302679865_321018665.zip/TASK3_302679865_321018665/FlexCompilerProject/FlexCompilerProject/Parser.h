#ifndef PARSER_H
#define PARSER_H

#include <stdio.h>
#include <stdlib.h>
#include "Token.h"
#include "Recover.h"
#include "Semantic.h"

void InitializeSyntacticFile(FILE* output);
FILE* getSemanticFile();
void printSyntacticError(Token *CurrentToken, int Kind);
void InitializeSemanticFile(FILE* output);

void parse_PROGRAM();
DataItem* parse_VAR_DEFINITIONS();
DataItem* parse_VAR_DEFINITION();
DataItem* parse_VAR_DEFINITIONS_1();
void parse_FUNC_DEFINITION();
DataItem* parse_TYPE();
DataItem* parse_VARIABLE(DataItem* dataItem);
DataItem* parse_VARIABLE_1();
DataItem* parse_VARIABLES_LIST(DataItem* dataItem);
DataItem* parse_VARIABLES_LIST_1(DataItem* dataItem);
void parse_FUNC_DEFINITIONS();
void parse_FUNC_DEFINITIONS_1();
DataItem* parse_RETURNED_TYPE();
DataItem* parse_PARAM_DEFINITIONS();
void parse_BLOCK(DataItem* dataItem);
void parse_STATEMENTS(DataItem* dataItem);
void parse_STATEMENTS_1(DataItem* dataItem);
void parse_STATEMENT(DataItem* dataItem);
DataItem* parse_STATEMENT_1();
DataItem* parse_STATEMENT_2();
DataItem* parse_EXPRESSION();
DataItem* parse_EXPRESSION_1();
DataItem* parse_PARAMETERS_LIST();

int match(int token);
void printRule(int rule);
char* kindToText(int kind);
#endif
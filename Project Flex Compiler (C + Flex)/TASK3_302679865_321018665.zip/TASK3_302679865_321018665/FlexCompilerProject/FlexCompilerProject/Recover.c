#include "Recover.h"
#include "Parser.h"

Token* recover_EOF(int Kind, Token *CurrentToken)
{
	printSyntacticError(CurrentToken, Kind);
	while (!follow_PROGRAM(CurrentToken->kind))
		CurrentToken = next_token();
	if (CurrentToken->kind == EOF_TOKEN)
		exit(0);
	else
		exit(1);
	return CurrentToken;
}

Token* recover_PROGRAM(int Kind, Token *CurrentToken)
{
	printSyntacticError(CurrentToken, Kind);
	while (!follow_PROGRAM(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
		CurrentToken = next_token();
	if (CurrentToken->kind == EOF_TOKEN) {
		printf("Error with recover_PROGRAM\n");
		exit(1);
	}
	else {
		CurrentToken = back_token();
	}
	return CurrentToken;
}

Token* recover_VAR_DEFINITIONS_1(int Kind, Token *CurrentToken)
{
	printSyntacticError(CurrentToken, Kind);
	while (!follow_VAR_DEFINITIONS_1(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
		CurrentToken = next_token();
	if (CurrentToken->kind == EOF_TOKEN) {
		printf("Error with recover_VAR_DEFINITIONS_1\n");
		exit(1);
	}
	else {
		CurrentToken = back_token();
	}
	return CurrentToken;
}

Token* recover_TYPE(int Kind, Token *CurrentToken)
{
	printSyntacticError(CurrentToken, Kind);
	while (!follow_TYPE(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
		CurrentToken = next_token();
	if (CurrentToken->kind == EOF_TOKEN) {
		printf("Error with in recover_TYPE\n");
		exit(1);
	}
	else {
		CurrentToken = back_token();
	}
	return CurrentToken;
}

Token* recover_VARIABLES_LIST(int Kind, Token *CurrentToken)
{
	printSyntacticError(CurrentToken, Kind);
	while (!follow_VARIABLES_LIST(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
		CurrentToken = next_token();
	if (CurrentToken->kind == EOF_TOKEN) {
		printf("Error with recover_VARIABLES_LIST\n");
		exit(1);
	}
	else {
		CurrentToken = back_token();
	}
	return CurrentToken;
}

Token* recover_VARIABLE(int Kind, Token *CurrentToken)
{
	printSyntacticError(CurrentToken, Kind);
	while (!follow_VARIABLE(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
		CurrentToken = next_token();
	if (CurrentToken->kind == EOF_TOKEN) {
		printf("Error with recover_VARIABLE\n");
		exit(1);
	}
	else {
		CurrentToken = back_token();
	}
	return CurrentToken;
}

Token* recover_VARIABLE_1(int Kind, Token *CurrentToken)
{
	printSyntacticError(CurrentToken, Kind);
	while (!follow_VARIABLE_1(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
		CurrentToken = next_token();
	if (CurrentToken->kind == EOF_TOKEN) {
		printf("Error with recover_VARIABLE_1\n");
		exit(1);
	}
	else {
		CurrentToken = back_token();
	}
	return CurrentToken;
}

Token* recover_FUNC_DEFINITION(int Kind, Token *CurrentToken)
{
	printSyntacticError(CurrentToken, Kind);
	while (!follow_FUNC_DEFINITION(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
		CurrentToken = next_token();
	if (CurrentToken->kind == EOF_TOKEN) {
		printf("Error with recover_FUNC_DEFINITION\n");
		exit(1);
	}
	else {
		CurrentToken = back_token();
	}
	return CurrentToken;
}

Token* recover_RETURNED_TYPE(int Kind, Token *CurrentToken)
{
	printSyntacticError(CurrentToken, Kind);
	while (!follow_RETURNED_TYPE(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
		CurrentToken = next_token();
	if (CurrentToken->kind == EOF_TOKEN) {
		printf("Error with recover_RETURNED_TYPE\n");
		exit(1);
	}
	else {
		CurrentToken = back_token();
	}
	return CurrentToken;
}

Token* recover_STATEMENT(int Kind, Token *CurrentToken)
{
	printSyntacticError(CurrentToken, Kind);
	while (!follow_STATEMENT(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
		CurrentToken = next_token();
	if (CurrentToken->kind == EOF_TOKEN) {
		printf("Error with recover_STATEMENT\n");
		exit(1);
	}
	else {
		CurrentToken = back_token();
	}
	return CurrentToken;
}

Token* recover_STATEMENTS(int Kind, Token *CurrentToken)
{
	printSyntacticError(CurrentToken, Kind);
	while (!follow_STATEMENTS(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
		CurrentToken = next_token();
	if (CurrentToken->kind == EOF_TOKEN) {
		printf("Error with recover_STATEMENTS\n");
		exit(1);
	}
	else {
		CurrentToken = back_token();
	}
	return CurrentToken;
}

Token* recover_BLOCK(int Kind, Token *CurrentToken)
{
	printSyntacticError(CurrentToken, Kind);
	while (!follow_BLOCK(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
		CurrentToken = next_token();
	if (CurrentToken->kind == EOF_TOKEN) {
		printf("error in recover_BLOCK\n");
		exit(1);
	}
	else {
		CurrentToken = back_token();
	}
	return CurrentToken;
}

Token* recover_EXPRESSION(int Kind, Token *CurrentToken)
{
	printSyntacticError(CurrentToken, Kind);
	while (!follow_EXPRESSION(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
		CurrentToken = next_token();
	if (CurrentToken->kind == EOF_TOKEN) {
		printf("Error with recover_EXPRESSION\n");
		exit(1);
	}
	else {
		CurrentToken = back_token();
	}
	return CurrentToken;
}

Token* recover_EXPRESSION_1(int Kind, Token *CurrentToken)
{
	printSyntacticError(CurrentToken, Kind);
	while (!follow_EXPRESSION_1(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
		CurrentToken = next_token();
	if (CurrentToken->kind == EOF_TOKEN) {
		printf("Error with recover_EXPRESSION_1\n");
		exit(1);
	}
	else {
		CurrentToken = back_token();
	}
	return CurrentToken;
}

Token* recover_STATEMENT_2(int Kind, Token *CurrentToken)
{
	printSyntacticError(CurrentToken, Kind);
	while (!follow_STATEMENT_2(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
		CurrentToken = next_token();
	if (CurrentToken->kind == EOF_TOKEN) {
		printf("Error with recover_STATEMENT_2\n");
		exit(1);
	}
	else {
		CurrentToken = back_token();
	}
	return CurrentToken;
}

Token* recover_FUNC_DEFINITIONS_1(int Kind, Token *CurrentToken)
{
	printSyntacticError(CurrentToken, Kind);
	while (!follow_FUNC_DEFINITIONS_1(CurrentToken->kind) && CurrentToken->kind != EOF_TOKEN)
		CurrentToken = next_token();
	if (CurrentToken->kind == EOF_TOKEN) {
		printf("Error with recover_FUNC_DEFINITIONS_1\n");
		exit(1);
	}
	else {
		CurrentToken = back_token();
	}
	return CurrentToken;
}



int follow_PROGRAM(int Token)
{
	if (Token == EOF_TOKEN)
		return 1;
	return 0;
}

int follow_VAR_DEFINITIONS(int Token)
{
	if (Token == SEMICOLON || Token == PARENTHESES_CLOSE)
		return 1;
	return 0;
}

int follow_VAR_DEFINITION(int Token)
{
	if (Token == SEMICOLON || Token == PARENTHESES_CLOSE)
		return 1;
	return 0;
}

int follow_VAR_DEFINITIONS_1(int Token)
{
	if (Token == SEMICOLON || Token == PARENTHESES_CLOSE)
		return 1;
	return 0;
}

int follow_FUNC_DEFINITION(int Token)
{
	if (Token == VOID || Token == REAL || Token == INTEGER || Token == EOF_TOKEN)
		return 1;
	return 0;
}

int follow_TYPE(int Token)
{
	if (Token == ID)
		return 1;
	return 0;
}

int follow_VARIABLE(int Token)
{
	if (Token == COMMA || Token == SEMICOLON || Token == PARENTHESES_CLOSE)
		return 1;
	return 0;
}

int follow_VARIABLE_1(int Token)
{
	if (Token == COMMA || Token == SEMICOLON || Token == ASSIGNMENT || Token == PARENTHESES_CLOSE)
		return 1;
	return 0;
}

int follow_VARIABLES_LIST(int Token)
{
	if (Token == SEMICOLON || Token == PARENTHESES_CLOSE)
		return 1;
	return 0;
}

int follow_VARIABLES_LIST_1(int Token)
{
	if (Token == SEMICOLON || Token == PARENTHESES_CLOSE)
		return 1;
	return 0;
}

int follow_FUNC_DEFINITIONS(int Token)
{
	if (Token == EOF_TOKEN)
		return 1;
	return 0;
}

int follow_FUNC_DEFINITIONS_1(int Token)
{
	if (Token == EOF_TOKEN)
		return 1;
	return 0;
}

int follow_RETURNED_TYPE(int Token)
{
	if (Token == ID)
		return 1;
	return 0;
}

int follow_PARAM_DEFINITIONS(int Token)
{
	if (Token == PARENTHESES_CLOSE)
		return 1;
	return 0;
}

int follow_BLOCK(int Token)
{
	if (Token == VOID || Token == REAL || Token == INTEGER || Token == EOF_TOKEN || Token == SEMICOLON)
		return 1;
	return 0;
}

int follow_STATEMENTS(int Token)
{
	if (Token == END || Token == BRACES_CLOSE)
		return 1;
	return 0;
}

int follow_STATEMENTS_1(int Token)
{
	if (Token == END || Token == BRACES_CLOSE)
		return 1;
	return 0;
}

int follow_STATEMENT(int Token)
{
	if (Token == SEMICOLON)
		return 1;
	return 0;
}

int follow_STATEMENT_1(int Token)
{
	if (Token == SEMICOLON)
		return 1;
	return 0;
}

int follow_STATEMENT_2(int Token)
{
	if (Token == SEMICOLON)
		return 1;
	return 0;
}

int follow_EXPRESSION(int Token)
{
	if (Token == SEMICOLON)
		return 1;
	return 0;
}

int follow_EXPRESSION_1(int Token)
{
	if (Token == SEMICOLON)
		return 1;
	return 0;
}

int follow_PARAMETERS_LIST(int Token)
{
	if (Token == PARENTHESES_CLOSE)
		return 1;
	return 0;
}



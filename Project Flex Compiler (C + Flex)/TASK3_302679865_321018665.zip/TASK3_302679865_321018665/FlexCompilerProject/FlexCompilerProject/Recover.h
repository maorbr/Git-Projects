#ifndef RECOVER_H
#define RECOVER_H

#include <stdio.h>
#include <stdlib.h>
#include"Token.h"

Token* recover_EOF(int Kind, Token *CurrentToken);
Token* recover_PROGRAM(int Kind, Token *CurrentToken);
Token* recover_VAR_DEFINITIONS_1(int Kind, Token *CurrentToken);
Token* recover_TYPE(int Kind, Token *CurrentToken);
Token* recover_VARIABLES_LIST(int Kind, Token *CurrentToken);
Token* recover_VARIABLE(int Kind, Token *CurrentToken);
Token* recover_VARIABLE_1(int Kind, Token *CurrentToken);
Token* recover_FUNC_DEFINITION(int Kind, Token *CurrentToken);
Token* recover_RETURNED_TYPE(int Kind, Token *CurrentToken);
Token* recover_STATEMENT(int Kind, Token *CurrentToken);
Token* recover_STATEMENT_2(int Kind, Token *CurrentToken);
Token* recover_STATEMENTS(int Kind, Token *CurrentToken);
Token* recover_BLOCK(int Kind, Token *CurrentToken);
Token* recover_EXPRESSION(int Kind, Token *CurrentToken);
Token* recover_EXPRESSION_1(int Kind, Token *CurrentToken);
Token* recover_FUNC_DEFINITIONS_1(int Kind, Token *CurrentToken);

int follow_PROGRAM(int Token);
int follow_VAR_DEFINITIONS(int Token);
int follow_VAR_DEFINITION(int Token);
int follow_VAR_DEFINITIONS_1(int Token);
int follow_FUNC_DEFINITION(int Token);
int follow_TYPE(int Token);
int follow_VARIABLE(int Token);
int follow_VARIABLE_1(int Token);
int follow_VARIABLES_LIST(int Token);
int follow_VARIABLES_LIST_1(int Token);
int follow_FUNC_DEFINITIONS(int Token);
int follow_FUNC_DEFINITIONS_1(int Token);
int follow_RETURNED_TYPE(int Token);
int follow_PARAM_DEFINITIONS(int Token);
int follow_BLOCK(int Token);
int follow_STATEMENTS(int Token);
int follow_STATEMENTS_1(int Token);
int follow_STATEMENT(int Token);
int follow_STATEMENT_1(int Token);
int follow_STATEMENT_2(int Token);
int follow_EXPRESSION(int Token);
int follow_EXPRESSION_1(int Token);
int follow_PARAMETERS_LIST(int Token);


#endif
#include "Semantic.h"
#include "Parser.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

SymbolTable* make_table(SymbolTable * curTable) {
	SymbolTable * newTable;
	int i;

	newTable = (SymbolTable *)malloc(sizeof(SymbolTable));
	newTable->father = curTable;
	for (i = 0; i<SIZE; i++) {
		newTable->dataItems[i] = NULL;
	}
	return newTable;
}

SymbolTable* pop_table(SymbolTable * curTable) {
	SymbolTable * temp = curTable;
	curTable = curTable->father;
	free(temp);
	return curTable;
}

DataItem* lookup(SymbolTable * curTable, char * idName) {
	DataItem *current; 
	int i;
	
	i = makeHash(idName);
	for (current = curTable->dataItems[i]; current != NULL; current = current->next)
	{
		if (strcmp(idName, current->id_name) == 0)
		{
			return current;
		}
	}
	return NULL;
}

DataItem* insert(SymbolTable * curTable, char * idName) {
	DataItem *item = NULL, *next = NULL, *last = NULL;
	int bin = 0;

	if (lookup(curTable, idName) != NULL) return NULL;
	bin = makeHash(idName);
	next = curTable->dataItems[bin];

	while (next != NULL && next->id_name != NULL && strcmp(idName, next->id_name) > 0)
	{
		last = next;
		next = next->next;
	}

	item = (DataItem*)malloc(sizeof(DataItem));

	if (next == curTable->dataItems[bin]) {
		item->next = next;
		curTable->dataItems[bin] = item;
	}
	else if (next == NULL) {
		last->next = item;
	}
	else {
		item->next = next;
		last->next = item;
	}

	item->id_name = _strdup(idName);

	return item;
}

DataItem* find(SymbolTable * curTable, char * idName, int lineNumber) {
	FILE *semanticFile = getSemanticFile();
	SymbolTable* tab = curTable;
	DataItem* id_entry;

	while (tab != NULL)
	{
		id_entry = lookup(tab, idName);
		if (id_entry != NULL)
			return (id_entry);
		else
			tab = tab->father;
	}
	fprintf(semanticFile,"ERROR: use of undeclared identifier: \"%s\", at line: %d.\n", idName, lineNumber);
	return NULL;
}

unsigned int makeHash(const char *id)
{
	unsigned int hash = 0, c;

	for (size_t i = 0; id[i] != '\0'; i++) {
		c = (unsigned char)id[i];
		hash = (hash << 3) + (hash >> (sizeof(hash) * CHAR_BIT - 3)) + c;
	}
	return hash % SIZE;
}

list * createList(void)
{
	list * newList = (list *)malloc(sizeof(list));
	if (newList) {
		newList->head = NULL;
		newList->tail = NULL;
	}

	return newList;
}

node * nodeCreate(varTypeItem * data)
{
	node * newNode = (node*)malloc(sizeof(node));
	if (newNode) {
		newNode->data = data;
		newNode->next = NULL;
	}

	return newNode;
}

void emptyList(list * list)
{
	node * node, *temp;
	node = list->head;
	while (node != NULL) {
		temp = node->next;
		free(node);
		node = temp;
	}
}

void deleteList(list * list)
{
	if (list) {
		emptyList(list);
		free(list);
	}
}

void addLastToList(list * list, varTypeItem * data)
{
	node * node = nodeCreate(data);
	if (!list->head) {
		list->head = node;
		list->tail = node;
	}
	else {
		list->tail->next = node;
		list->tail = node;
	}
}

void addListToList(list * listLeft, list * listRight)
{
	if (listRight && listRight->head)
		addLastToList(listLeft, listRight->head->data);
}
int equalListToList(list * listLeft, list * listRight) {
	node * currentLeft, *currentRight;
	currentLeft = listLeft->head;
	currentRight = listRight->head;
	if (currentLeft->data->type != currentRight->data->type || currentLeft->data->size != currentRight->data->size)
		return 0;
	while (currentLeft->next && currentRight->next) {
		currentLeft = currentLeft->next;
		currentRight = currentRight->next;
		if (currentLeft->data->type != currentRight->data->type || currentLeft->data->size != currentRight->data->size)
			return 0;
	}
	if (currentLeft->next || currentRight->next)
		return 0;
	return 1;
}

DataItem* initializeDataItem() {
	DataItem* newDataItem = (DataItem*)malloc(sizeof(DataItem));
	newDataItem->id_name = NULL;
	newDataItem->next = NULL;
	newDataItem->listOfParams = NULL;
	newDataItem->sizeOfParams = -1;
	newDataItem->returnType = VOID_type;
	newDataItem->varType = NULL_type;
	newDataItem->size = -1;

	return newDataItem;
}
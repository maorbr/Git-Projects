#ifndef SEMANTIC_H
#define SEMANTIC_H
#define SIZE 20000

typedef enum types {
	INTEGER_type, REAL_type, VOID_type, NULL_type
}types;

typedef struct varTypeItem {
	char *id_name;
	int size;
	types type;
}varTypeItem;

typedef struct node {
	varTypeItem * data;
	struct node * next;
}node;

typedef struct list {
	node * head;
	node * tail;
}list;

typedef struct DataItem {
	char *id_name;
	types varType;
	int size; 

	types returnType;
	int sizeOfParams;
	list * listOfParams;

	struct DataItem * next;
}DataItem;

typedef struct symbolTable {
	DataItem * dataItems[SIZE];
	struct symbolTable * father;
}SymbolTable;

SymbolTable* make_table(SymbolTable * curTable);
SymbolTable* pop_table(SymbolTable * curTable);
DataItem* lookup(SymbolTable * curTable, char * idName);
DataItem* insert(SymbolTable * curTable, char * idName);
DataItem* find(SymbolTable * curTable, char * idName, int lineNumber);

unsigned int makeHash(const char *id);
list * createList();
node * nodeCreate(varTypeItem * data);
void emptyList(list * list);
void deleteList(list * list);
void addLastToList(list * list, varTypeItem * data);
void addListToList(list * listLeft, list * listRight);
int equalListToList(list * listLeft, list * listRight);
DataItem* initializeDataItem();

#endif

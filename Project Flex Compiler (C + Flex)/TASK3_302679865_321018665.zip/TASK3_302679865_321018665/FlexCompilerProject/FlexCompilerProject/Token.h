#ifndef TOKEN_H
#define TOKEN_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern FILE *yyin, *yyout;
extern int yylex();

typedef enum eTOKENS
{
	EOF_TOKEN,

	PROGRAM,
	END,
	REAL,
	INTEGER,
	VOID,
	RETURN,

	SEMICOLON,
	COMMA,
	PARENTHESES_OPEN,
	PARENTHESES_CLOSE,
	BRACKETS_OPEN,
	BRACKETS_CLOSE,
	BRACES_OPEN,
	BRACES_CLOSE,

	MULTIPLICATION,
	DIVISION,
	ASSIGNMENT,
	
	ID,
	INT_NUMBER,
	REAL_NUMBER,

	UNDEFINED
}eTOKENS;

typedef struct Token
{
	eTOKENS kind;
	char *lexeme;
	int lineNumber;
}Token;

typedef struct Node
{
	Token *tokensArray;
	struct Node *prev;
	struct Node *next;
} Node;

void create_and_store_token(eTOKENS kind, char* lexeme, int numOfLine);
eTOKENS Handle_token(eTOKENS kind, char* lexeme, int numOfLine);
Token *next_token();
Token *back_token();
void initiate();

#endif